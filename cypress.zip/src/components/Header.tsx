"use client";


import React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Toolbar from "@mui/material/Toolbar";
import LogoutIcon from "@mui/icons-material/Logout";

// NextAuth
import { useSession, signOut } from "next-auth/react";

export default function Navbar() {
  const router = useRouter();

  // NextAuth session
  const { data: session, status } = useSession();
  const isLoggedIn = !!session;
  const loading = status === "loading";

  const handleLogout = async () => {
    await signOut({});
    /* router.push("/login"); */
  };

  /*   const medievalTheme = createTheme({
      palette: {
        mode: 'dark',
        primary: {
          main: '#e7d1ac',
        },
      },
    });
   */
   // ⛔ ESSENCIAL PARA EVITAR HYDRATION ERROR
  if (status === "loading") {
    return <div style={{ height: 64 }} />; // mesma altura do AppBar
  }

  return (
    <Box sx={{ flexGrow: 1 }}>
      {/*   <ThemeProvider theme={medievalTheme}> */}
      <AppBar position="static" color="primary" enableColorOnDark>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            GraphQL Dashboard
          </Typography>

          {/* Evitar hydration error */}
          {loading ? (
            <div
              style={{
                height: "36.5px",
              }}
            ></div>
          ) : (
            <>
              {isLoggedIn && (
                <>
                  <Button color="inherit" component={Link} href="/stepper" data-testid="nav-stepper">
                    Passo a Passo
                  </Button>
                  <Button color="inherit" component={Link} href="/progresso" data-testid="nav-progress">
                    Progresso
                  </Button>
                  <Button color="inherit" component={Link} href="/users" data-testid="nav-users">
                    Usuários
                  </Button>
                  <Button color="inherit" component={Link} href="/posts" data-testid="nav-posts">
                    Posts
                  </Button>
                  <Button color="inherit" component={Link} href="/post_subcription" data-testid="nav-post-sub">
                    Posts Sub
                  </Button>
                  <Button color="inherit" component={Link} href="/create_post" data-testid="nav-create-post">
                    Criar Post
                  </Button>

                  <IconButton color="inherit" onClick={handleLogout} data-testid="nav-logout">
                    <LogoutIcon />
                  </IconButton>
                </>
              )}

              {/*  {!isLoggedIn && (
                <Button color="inherit" component={Link} href="/login">
                  Login
                </Button>
              )} */}
            </>
          )}
        </Toolbar>
      </AppBar>
      {/* </ThemeProvider> */}
    </Box>
  );
}
