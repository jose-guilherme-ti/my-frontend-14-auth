/// <reference types="cypress" />

describe("Fluxo completo: Login + Navegação pelo Header", () => {

  //
  // ================================
  // 🔐 SESSION (evita re-login)
  // ================================
  //
  beforeEach(() => {
    cy.session("login-session", () => {
      cy.visit("http://localhost:3000/login");

      // Verifica se carregou inputs (evita hydration error)
      cy.get('[data-testid="login-email"]', { timeout: 8000 }).should("exist");
      cy.get('[data-testid="login-password"]').should("exist");

      // Preenche login
      cy.get('[data-testid="login-email"]').type("admin@example.com");
      cy.get('[data-testid="login-password"]').type("123456");

      cy.get('[data-testid="login-submit"]').click();

      // Login não deve falhar
      cy.url().should("not.include", "/login");
      cy.contains("GraphQL Dashboard", { timeout: 8000 }).should("exist");
    });
  });

  //
  // ================================
  // 📌 TESTE FINAL: Navegação HEADER
  // ================================
  //
  it("Testa navegação do Header - esquerda → direita", () => {
    cy.visit("http://localhost:3000/");

    // Aguarda Header montar
    cy.contains("GraphQL Dashboard", { timeout: 8000 }).should("exist");

    //
    // ORDEM DA ESQUERDA → DIREITA
    //

    cy.get('[data-testid="nav-stepper"]').click();
    cy.url().should("include", "/stepper");
    cy.go("back");

    cy.get('[data-testid="nav-progress"]').click();
    cy.url().should("include", "/progresso");
    cy.go("back");

    cy.get('[data-testid="nav-users"]').click();
    cy.url().should("include", "/users");
    cy.go("back");

    cy.get('[data-testid="nav-posts"]').click();
    cy.url().should("include", "/posts");
    cy.go("back");

    cy.get('[data-testid="nav-post-sub"]').should('exist').click();
    cy.get('[data-testid="nav-post-sub"]').click();
    cy.url().should("include", "/post_subcription");
    cy.go("back");

    cy.get('[data-testid="nav-create-post"]').should('exist').click();
    cy.get('[data-testid="nav-create-post"]').click();
    cy.url().should("include", "/create_post");
    cy.go("back");

    // Logout sempre por último
    cy.get('[data-testid="nav-logout"]').click();
    cy.url().should("include", "/login");
  });
});
