describe("Fluxo completo - Login + Formulário Stepper", () => {
    before(() => {
        cy.visit("http://localhost:3000/login");

        cy.get('[data-testid="login-email"]')
            .should("be.visible")
            .type("admin@example.com");

        cy.get('[data-testid="login-password"]')
            .should("be.visible")
            .type("123456");

        cy.get('[data-testid="login-submit"]').click();

        // Deve redirecionar para dashboard após login
        cy.url().should("include", "/");
    });

    it("Deve acessar o formulário Stepper", () => {
        cy.get('[data-testid="nav-stepper"]', { timeout: 20000 })
            .should("be.visible")
            .click();

        //cy.url().should("include", "/stepper");
        cy.get('[data-testid="nav-stepper"]').click().should("be.visible");
        cy.url().should("include", "http://localhost:3000/stepper");
        //cy.contains("Super Stepper Final", { timeout: 15000 }).should("exist");
    });

    it("Step 1 - Deve preencher dados pessoais", () => {
        //cy.contains("Dados pessoais", { timeout: 10000 }).should("exist");
        cy.get('[data-testid="input-name"]', { timeout: 10000 })
            .should("be.enabled")
            .type("José Guilherme");

        cy.get('input[name="email"]').type("jose@example.com");
        cy.get('input[name="cpf"]').type("123.456.789-09");
        cy.get('input[name="phone"]').type("(11) 99999-9999");

        cy.contains("Próximo").click();
    });

    it("Step 2 - Deve preencher endereço", () => {
        //cy.contains("Endereço", { timeout: 10000 }).should("exist");

        cy.get('input[name="cep"]').type("01001-000");

        // Espera o autoPreenchimento carregar
        cy.get('input[name="street"]', { timeout: 15000 })
            .should("be.visible");

        cy.get('input[name="street"]').type("Praça da Sé");
        cy.get('input[name="district"]').type("Centro");
        cy.get('input[name="city"]').type("São Paulo");

        cy.contains("Próximo").click();
    });

    it("Step 3 - Deve finalizar", () => {
        //cy.contains("Confirmação", { timeout: 10000 }).should("exist");

        cy.get('input[name="occupation"]').type("Desenvolvedor");
        cy.get('input[name="income"]').type("4500");
        cy.get('textarea[name="description"]').type("Teste completo");

        cy.contains("Finalizar").click();

        cy.on("window:alert", (txt) => {
            expect(txt).to.contains("Finalizado");
        });

        cy.contains("Prévia do objeto final", { timeout: 10000 }).should("exist");
    });
});